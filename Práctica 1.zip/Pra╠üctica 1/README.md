# Práctica no. 1

Para ejecutar los scripts de esta práctica se puede utilizar el comando make
seguido como argumento 'analisis', 'reg', o 'grad'. Make se encuentra en la
mayoría de sistemas UNIX, aunque en caso de no tenerlo se puede revisar el
script de make donde se encuentran los comandos que se ejecutan para correr los
script

